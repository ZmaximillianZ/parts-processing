create function age(timestamp with time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$
select pg_catalog.age(cast(current_date as timestamp with time zone), $1)
$$;

comment on function age(timestamp with time zone) is 'date difference from today preserving months and years';

alter function age(timestamp with time zone) owner to postgres;

