create view hdb_unique_constraint(table_name, table_schema, constraint_name, columns) as
SELECT tc.table_name,
       tc.constraint_schema      AS table_schema,
       tc.constraint_name,
       json_agg(kcu.column_name) AS columns
FROM information_schema.table_constraints tc
         JOIN information_schema.key_column_usage kcu USING (constraint_schema, constraint_name)
WHERE tc.constraint_type::text = 'UNIQUE'::text
GROUP BY tc.table_name, tc.constraint_schema, tc.constraint_name;

alter table hdb_unique_constraint
    owner to postgres;

