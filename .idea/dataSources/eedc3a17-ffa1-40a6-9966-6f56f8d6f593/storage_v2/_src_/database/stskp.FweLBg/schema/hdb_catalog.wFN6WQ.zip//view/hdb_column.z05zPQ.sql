create view hdb_column
            (table_schema, table_name, name, type, is_nullable, ordinal_position, primary_key_references,
             description) as
WITH primary_key_references AS (
    SELECT fkey.table_schema                                                                          AS src_table_schema,
           fkey.table_name                                                                            AS src_table_name,
           fkey.columns ->> 0                                                                         AS src_column_name,
           json_agg(json_build_object('schema', fkey.ref_table_table_schema, 'name', fkey.ref_table)) AS ref_tables
    FROM hdb_catalog.hdb_foreign_key_constraint fkey
             JOIN hdb_catalog.hdb_primary_key pkey ON pkey.table_schema::text = fkey.ref_table_table_schema AND
                                                      pkey.table_name::text = fkey.ref_table AND
                                                      pkey.columns::jsonb = fkey.ref_columns::jsonb
    WHERE json_array_length(fkey.columns) = 1
    GROUP BY fkey.table_schema, fkey.table_name, (fkey.columns ->> 0)
)
SELECT columns.table_schema,
       columns.table_name,
       columns.column_name                                              AS name,
       columns.udt_name                                                 AS type,
       columns.is_nullable,
       columns.ordinal_position,
       COALESCE(pkey_refs.ref_tables, '[]'::json)                       AS primary_key_references,
       col_description(pg_class.oid, columns.ordinal_position::integer) AS description
FROM information_schema.columns
         JOIN pg_class ON pg_class.relname = columns.table_name::name
         JOIN pg_namespace ON pg_namespace.oid = pg_class.relnamespace AND pg_namespace.nspname = columns.table_schema::name
         LEFT JOIN primary_key_references pkey_refs ON columns.table_schema::text = pkey_refs.src_table_schema AND
                                                       columns.table_name::text = pkey_refs.src_table_name AND
                                                       columns.column_name::text = pkey_refs.src_column_name;

alter table hdb_column
    owner to postgres;

