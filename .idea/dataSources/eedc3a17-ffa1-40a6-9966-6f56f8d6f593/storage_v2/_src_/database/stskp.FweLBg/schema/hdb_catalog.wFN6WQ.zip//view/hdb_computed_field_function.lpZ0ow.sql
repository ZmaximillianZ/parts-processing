create view hdb_computed_field_function
            (table_schema, table_name, computed_field_name, function_name, function_schema) as
SELECT hdb_computed_field.table_schema,
       hdb_computed_field.table_name,
       hdb_computed_field.computed_field_name,
       CASE
           WHEN ((hdb_computed_field.definition -> 'function'::text) ->> 'name'::text) IS NULL
               THEN hdb_computed_field.definition ->> 'function'::text
           ELSE (hdb_computed_field.definition -> 'function'::text) ->> 'name'::text
           END AS function_name,
       CASE
           WHEN ((hdb_computed_field.definition -> 'function'::text) ->> 'schema'::text) IS NULL THEN 'public'::text
           ELSE (hdb_computed_field.definition -> 'function'::text) ->> 'schema'::text
           END AS function_schema
FROM hdb_catalog.hdb_computed_field;

alter table hdb_computed_field_function
    owner to postgres;

