create view hdb_check_constraint(table_schema, table_name, constraint_name, "check") as
SELECT n.nspname::text                   AS table_schema,
       ct.relname::text                  AS table_name,
       r.conname::text                   AS constraint_name,
       pg_get_constraintdef(r.oid, true) AS "check"
FROM pg_constraint r
         JOIN pg_class ct ON r.conrelid = ct.oid
         JOIN pg_namespace n ON ct.relnamespace = n.oid
WHERE r.contype = 'c'::"char";

alter table hdb_check_constraint
    owner to postgres;

