create view hdb_table_info_agg
            (table_name, table_schema, description, columns, primary_key_columns, constraints, view_info) as
SELECT tables.table_name,
       tables.table_schema,
       descriptions.description,
       COALESCE(columns.columns, '[]'::json)         AS columns,
       COALESCE(pk.columns, '[]'::json)              AS primary_key_columns,
       COALESCE(constraints.constraints, '[]'::json) AS constraints,
       COALESCE(views.view_info, 'null'::json)       AS view_info
FROM information_schema.tables tables
         LEFT JOIN (SELECT c.table_name,
                           c.table_schema,
                           json_agg(json_build_object('name', c.name, 'type', c.type, 'is_nullable',
                                                      c.is_nullable::boolean, 'references', c.primary_key_references,
                                                      'description', c.description)) AS columns
                    FROM hdb_catalog.hdb_column c
                    GROUP BY c.table_schema, c.table_name) columns
                   ON tables.table_schema::text = columns.table_schema::text AND
                      tables.table_name::text = columns.table_name::text
         LEFT JOIN (SELECT hdb_primary_key.table_schema,
                           hdb_primary_key.table_name,
                           hdb_primary_key.constraint_name,
                           hdb_primary_key.columns
                    FROM hdb_catalog.hdb_primary_key) pk
                   ON tables.table_schema::text = pk.table_schema::text AND tables.table_name::text = pk.table_name::text
         LEFT JOIN (SELECT c.table_schema,
                           c.table_name,
                           json_agg(c.constraint_name) AS constraints
                    FROM information_schema.table_constraints c
                    WHERE c.constraint_type::text = 'UNIQUE'::text
                       OR c.constraint_type::text = 'PRIMARY KEY'::text
                    GROUP BY c.table_schema, c.table_name) constraints
                   ON tables.table_schema::text = constraints.table_schema::text AND
                      tables.table_name::text = constraints.table_name::text
         LEFT JOIN (SELECT v.table_schema,
                           v.table_name,
                           json_build_object('is_updatable', v.is_updatable::boolean OR v.is_trigger_updatable::boolean,
                                             'is_deletable', v.is_updatable::boolean OR v.is_trigger_deletable::boolean,
                                             'is_insertable', v.is_insertable_into::boolean OR
                                                              v.is_trigger_insertable_into::boolean) AS view_info
                    FROM information_schema.views v) views ON tables.table_schema::text = views.table_schema::text AND
                                                              tables.table_name::text = views.table_name::text
         LEFT JOIN (SELECT pc.relname AS table_name,
                           pn.nspname AS table_schema,
                           pd.description
                    FROM pg_class pc
                             LEFT JOIN pg_namespace pn ON pn.oid = pc.relnamespace
                             LEFT JOIN pg_description pd ON pd.objoid = pc.oid
                    WHERE pd.objsubid = 0) descriptions ON tables.table_schema::name = descriptions.table_schema AND
                                                           tables.table_name::name = descriptions.table_name;

alter table hdb_table_info_agg
    owner to postgres;

