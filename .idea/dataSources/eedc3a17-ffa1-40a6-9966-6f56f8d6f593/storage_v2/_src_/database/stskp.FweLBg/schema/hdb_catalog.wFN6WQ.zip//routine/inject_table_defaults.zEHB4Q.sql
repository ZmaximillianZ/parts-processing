create function inject_table_defaults(view_schema text, view_name text, tab_schema text, tab_name text) returns void
    language plpgsql
as
$$
DECLARE
        r RECORD;
    BEGIN
      FOR r IN SELECT column_name, column_default FROM information_schema.columns WHERE table_schema = tab_schema AND table_name = tab_name AND column_default IS NOT NULL LOOP
          EXECUTE format('ALTER VIEW %I.%I ALTER COLUMN %I SET DEFAULT %s;', view_schema, view_name, r.column_name, r.column_default);
      END LOOP;
    END;
$$;

alter function inject_table_defaults(text, text, text, text) owner to postgres;

