create view hdb_function_info_agg(function_name, function_schema, function_info) as
SELECT hdb_function_agg.function_name,
       hdb_function_agg.function_schema,
       row_to_json((SELECT e.*::record AS e
                    FROM (SELECT hdb_function_agg.description,
                                 hdb_function_agg.has_variadic,
                                 hdb_function_agg.function_type,
                                 hdb_function_agg.return_type_schema,
                                 hdb_function_agg.return_type_name,
                                 hdb_function_agg.return_type_type,
                                 hdb_function_agg.returns_set,
                                 hdb_function_agg.input_arg_types,
                                 hdb_function_agg.input_arg_names,
                                 hdb_function_agg.default_args,
                                 (EXISTS(SELECT 1
                                         FROM information_schema.tables
                                         WHERE tables.table_schema::text = hdb_function_agg.return_type_schema
                                           AND tables.table_name::text = hdb_function_agg.return_type_name)) AS returns_table) e)) AS function_info
FROM hdb_catalog.hdb_function_agg;

alter table hdb_function_info_agg
    owner to postgres;

