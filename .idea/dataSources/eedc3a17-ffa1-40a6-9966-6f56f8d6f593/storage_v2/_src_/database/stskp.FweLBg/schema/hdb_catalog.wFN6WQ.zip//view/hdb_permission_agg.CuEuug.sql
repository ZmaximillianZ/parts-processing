create view hdb_permission_agg(table_schema, table_name, role_name, permissions) as
SELECT hdb_permission.table_schema,
       hdb_permission.table_name,
       hdb_permission.role_name,
       json_object_agg(hdb_permission.perm_type, hdb_permission.perm_def) AS permissions
FROM hdb_catalog.hdb_permission
GROUP BY hdb_permission.table_schema, hdb_permission.table_name, hdb_permission.role_name;

alter table hdb_permission_agg
    owner to postgres;

